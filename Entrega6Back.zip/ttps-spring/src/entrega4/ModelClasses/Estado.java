package entrega4.ModelClasses;
import javax.persistence.*;

@Entity
public class Estado{
	
	@Id @GeneratedValue
    @Column(name="ESTADO_ID")
	private Long id;
	
	private String estado;
	
	@OneToOne
	private Reserva reserva;
	
	public Estado() {}
	
	public Estado(String estado, Reserva reserva) {
		super();
		this.estado = estado;
		this.reserva = reserva;
	}

	public String getEstado() {
		return estado;
	}

	public void setEstado(String estado) {
		this.estado = estado;
	}

	

}
