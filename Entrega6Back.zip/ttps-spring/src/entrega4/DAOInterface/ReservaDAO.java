package entrega4.DAOInterface;

import entrega4.ModelClasses.Reserva;

public interface ReservaDAO extends GenericDAO<Reserva> {

}
