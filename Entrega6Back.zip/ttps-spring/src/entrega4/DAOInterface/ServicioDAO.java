package entrega4.DAOInterface;


import entrega4.ModelClasses.Servicio;

public interface ServicioDAO extends GenericDAO<Servicio> {

	

	


}
