package entrega4.DAOInterface;

import entrega4.ModelClasses.Valoracion;

public interface ValoracionDAO extends GenericDAO<Valoracion> {

}
