package entrega4.DAOInterface;


import java.util.List;

import entrega4.ModelClasses.Servicio;

public interface ServicioDAO extends GenericDAO<Servicio> {

	

	


}
