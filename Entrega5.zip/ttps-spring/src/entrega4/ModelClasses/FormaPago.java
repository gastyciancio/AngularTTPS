package entrega4.ModelClasses;
import javax.persistence.*;

@Entity
public class FormaPago {
	
	@Id @GeneratedValue
    @Column(name="FORMA_PAGO_ID")
	private Long id;
	
	@OneToOne
	private Reserva reserva;
	
	private String forma_pago;
	
	public FormaPago() {}
	
	public FormaPago(String forma_pago, Reserva reserva) {
		super();
		this.forma_pago = forma_pago;
		this.reserva = reserva;
	}

	public String getForma_pago() {
		return forma_pago;
	}

	public void setForma_pago(String forma_pago) {
		this.forma_pago = forma_pago;
	}


}
