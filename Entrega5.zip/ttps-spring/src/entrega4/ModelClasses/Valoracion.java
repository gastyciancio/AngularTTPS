package entrega4.ModelClasses;
import javax.persistence.*;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
public class Valoracion {
	
	@Id @GeneratedValue
    @Column(name="VALORACION_ID")
	private Long id;
	
	@ManyToOne
	@JoinColumn(name="servicio_id")
	@JsonIgnore
	private Servicio servicio;
	
	private int limpieza;
	private int calidad_precio;
	private int simpatia;
	
	public Valoracion(int limpieza, int calidad_precio, int simpatia) {
		super();
		this.limpieza = limpieza;
		this.calidad_precio = calidad_precio;
		this.simpatia = simpatia;
	}
	
	public Valoracion() {}
	
	public int getLimpieza() {
		return limpieza;
	}
	public void setLimpieza(int limpieza) {
		this.limpieza = limpieza;
	}
	public int getCalidad_precio() {
		return calidad_precio;
	}
	public void setCalidad_precio(int calidad_precio) {
		this.calidad_precio = calidad_precio;
	}
	public int getSimpatia() {
		return simpatia;
	}
	public void setSimpatia(int simpatia) {
		this.simpatia = simpatia;
	}
	

}
