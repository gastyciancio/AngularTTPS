package entrega4.DAOInterface;

import entrega4.ModelClasses.Estado;

public interface EstadoDAO extends GenericDAO<Estado> {

}
