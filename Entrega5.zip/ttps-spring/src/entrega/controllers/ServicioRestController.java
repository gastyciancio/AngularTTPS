package entrega.controllers;

import java.util.Map;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import entrega4.DAOInterface.ServicioDAO;
import entrega4.DAOInterface.UsuarioDAO;
import entrega4.ModelClasses.Servicio;
import entrega4.ModelClasses.Usuario;

	
@RestController
@CrossOrigin(origins = "http://localhost:4200")
@RequestMapping(value="/servicio", produces=MediaType.APPLICATION_JSON_VALUE)

public class ServicioRestController {

@Autowired
ServicioDAO servicioDAO;

@Autowired
UsuarioDAO usuarioDAO;

//creo un servicio
@PostMapping
public ResponseEntity<Servicio> createService(@RequestBody Servicio serv, 
		 @RequestHeader Map<String, String> mapHeaders,@RequestHeader("idPersona") int idP) {
	 Usuario user = usuarioDAO.findById(idP);
	 user.getServicios().add(serv);
	 serv.setUsuario(user);
	 usuarioDAO.actualizar(user);
	 return new ResponseEntity<Servicio>(serv, HttpStatus.CREATED);
}


//modifico un servicio a partir de su id 
@PutMapping("/{id}")
public ResponseEntity<Servicio> editService(@PathVariable("id") int id,@RequestBody Servicio serv) {

			try 
			{
				Servicio servBD = servicioDAO.findById(id);
				servBD.setDescripcion(serv.getDescripcion());
				servBD.setNombre(serv.getNombre());
				servBD.setImagenes(serv.getImagenes());
				servBD.setTipo(serv.getTipo());
				servBD.setTwitter(serv.getTwitter());
				servBD.setInstagram(serv.getInstagram());
				servBD.setUrl(serv.getUrl());
				servBD.setWhatsapp(serv.getWhatsapp());
				servBD.setValoraciones(serv.getValoraciones());
				servicioDAO.actualizar(servBD);
				return new ResponseEntity<Servicio>(servBD, HttpStatus.OK);
				
			}
			catch(Exception e) 
			{
				return new ResponseEntity<Servicio>(HttpStatus.NOT_FOUND);
			}
		}

@PutMapping("/borrar/{id}")
public ResponseEntity<Servicio> deleteService(@PathVariable("id") long id){

	try{
		int myInt = (int) id;
		Servicio serv= servicioDAO.findById(myInt);
		Usuario u=serv.getUsuario();
		u.getServicios().remove(serv);
		serv.setUsuario(null);
		servicioDAO.actualizar(serv);
		return new ResponseEntity<Servicio>(serv, HttpStatus.OK);
			
		}catch(Exception e) {
			e.printStackTrace();
			return new ResponseEntity<Servicio>(HttpStatus.NOT_FOUND);
		}
	
}

@PutMapping("/borrar2/{id}")
public ResponseEntity<Servicio> deleteService2(@PathVariable("id") long id){
	try{
		int myInt = (int) id;
		Servicio serv= servicioDAO.findById(myInt);
		servicioDAO.borrar(serv);

		return new ResponseEntity<Servicio>(serv, HttpStatus.OK);
			
		}catch(Exception e) {
			e.printStackTrace();
			return new ResponseEntity<Servicio>(HttpStatus.NOT_FOUND);
		}
	
		
	
		
	
	
		
	
	


}

		
}













	




