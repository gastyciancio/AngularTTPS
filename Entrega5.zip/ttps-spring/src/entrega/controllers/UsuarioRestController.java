package entrega.controllers;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


import entrega4.DAOInterface.UsuarioDAO;
import entrega4.ModelClasses.Servicio;
import entrega4.ModelClasses.Usuario;



	
@RestController
@CrossOrigin(origins = "http://localhost:4200")
@RequestMapping(value="/usuario", produces=MediaType.APPLICATION_JSON_VALUE)


public class UsuarioRestController {
	
@Autowired
UsuarioDAO usuarioDAO;
	 
//Recupero todos los usuarios

@PostMapping
public ResponseEntity<Usuario> createUser(@RequestBody Usuario user, 
		 @RequestHeader Map<String, String> mapHeaders) {
	
	 Usuario u =usuarioDAO.persistir(user);
	 return new ResponseEntity<Usuario>(u, HttpStatus.CREATED);
}


@GetMapping
public ResponseEntity<List<Usuario>> listAllUsers(@RequestHeader("token") String token,
		 @RequestHeader Map<String, String> mapHeaders) {
	
	 List<Usuario> users = usuarioDAO.recuperarTodos("nombre");
	 if(users.isEmpty()){
	 return new ResponseEntity<List<Usuario>>(HttpStatus.NO_CONTENT);
	 }
	 return new ResponseEntity<List<Usuario>>(users, HttpStatus.OK);
	 }

	//Recupero un usuario dado
@GetMapping("/{id}")
	public ResponseEntity<Usuario> getUser(@PathVariable("id") int id,@RequestHeader("token") String token) {
		
		if (permitido(String.valueOf(id),token))
		{
			try 
			{
				Usuario user = usuarioDAO.findById(id);
				return new ResponseEntity<Usuario>(user, HttpStatus.OK);
			}
			catch(Exception e) 
			{
				return new ResponseEntity<Usuario>(HttpStatus.NOT_FOUND);
			}
		}
		else
			return new ResponseEntity<Usuario>(HttpStatus.UNAUTHORIZED);
	}

@GetMapping("/{id}/servicios")
public ResponseEntity<List<Servicio>> getUserServices(@PathVariable("id") int id,@RequestHeader("token") String token) {
	
	if (permitido(String.valueOf(id),token))
	{
		try 
		{
			Usuario user = usuarioDAO.findById(id);
			List<Servicio> s=user.getServicios();
			return new ResponseEntity<List<Servicio>>(s, HttpStatus.OK);
		}
		catch(Exception e) 
		{
			return new ResponseEntity<List<Servicio>>(HttpStatus.NOT_FOUND);
		}
	}
	else
		return new ResponseEntity<List<Servicio>>(HttpStatus.UNAUTHORIZED);
}

@PutMapping("/{id}")
public ResponseEntity<Usuario> putUser(@PathVariable("id") int id,@RequestHeader("token") String token,@RequestBody Usuario user) {

		if (permitido(String.valueOf(id),token)) 
		{
			try 
			{
				Usuario usuarioBD = usuarioDAO.findById(id);
				System.out.println("Usuario con id " + id + " encontrado. Vamos a actualizarlo");
				usuarioBD.setNombre_usuario(user.getNombre_usuario());
				usuarioBD.setApellido(user.getApellido());
				usuarioBD.setNombre(user.getNombre());
				usuarioBD.setContrase�a(user.getContrase�a());
				usuarioBD.setEmail(user.getEmail());
				usuarioDAO.actualizar(usuarioBD);
				return new ResponseEntity<Usuario>(usuarioBD, HttpStatus.OK);
			}
			catch(Exception e) 
			{
				return new ResponseEntity<Usuario>(HttpStatus.NOT_FOUND);
			}
		}
		else
			return new ResponseEntity<Usuario>(HttpStatus.UNAUTHORIZED);
}


private boolean permitido(String id, String token) {
	
	String[] parts = token.split("-");
	String part1 = parts[0]; //id usuario
	String part2 = parts[1]; // 123456
	return part1.equals(String.valueOf(id)) && (part2.equals("123456"));
}

@DeleteMapping("/borrar/{id}")
public ResponseEntity<Usuario> deleteService(@PathVariable("id") long id){
	try{
		int myInt = (int) id;
		Usuario u= usuarioDAO.findById(myInt);
		usuarioDAO.borrar(u);
		return new ResponseEntity<Usuario>(u, HttpStatus.OK);
		
	}catch(Exception e) {
		e.printStackTrace();
		return new ResponseEntity<Usuario>(HttpStatus.NOT_FOUND);
	}
}

}







